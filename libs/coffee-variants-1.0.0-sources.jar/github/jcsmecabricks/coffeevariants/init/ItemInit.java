package github.jcsmecabricks.coffeevariants.init;

import github.jcsmecabricks.coffeevariants.CoffeeVariants;
import github.jcsmecabricks.coffeevariants.custom.CoffeeItem;
import github.jcsmecabricks.coffeevariants.custom.ModConsumableComponents;
import github.jcsmecabricks.coffeevariants.custom.ModFoodComponents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ItemInit {

    public static final class_1792 COFFEE_CUP = register("coffee_cup", new class_1792(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, "coffee_cup")))));

    public static final class_1792 COFFEE_ITEM = register("coffee_item", new CoffeeItem(new class_1792.class_1793()
            .method_62833(ModFoodComponents.COFFEE_FOOD, ModConsumableComponents.COFFEE_DRINK)
            .method_7889(1)
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, "coffee_item")))));

    public static final class_1792 LATTE = register("latte", new CoffeeItem(new class_1792.class_1793()
            .method_62833(ModFoodComponents.LATTE, ModConsumableComponents.COFFEE_DRINK)
            .method_7889(1)
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, "latte")))));

    public static final class_1792 CAPPUCCINO = register("cappuccino", new CoffeeItem(new class_1792.class_1793()
            .method_62833(ModFoodComponents.CAPPUCCINO, ModConsumableComponents.COFFEE_DRINK)
            .method_7889(1)
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, "cappuccino")))));

    public static final class_1792 MOCHA = register("mocha", new CoffeeItem(new class_1792.class_1793()
            .method_62833(ModFoodComponents.MOCHA, ModConsumableComponents.COFFEE_DRINK)
            .method_7889(1)
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, "mocha")))));

    public static final class_1792 ESPRESSO = register("espresso", new CoffeeItem(new class_1792.class_1793()
            .method_62833(ModFoodComponents.ESPRESSO, ModFoodComponents.CAFFEINE_EFFECT)
            .method_7889(1)
            .method_62833(ModFoodComponents.ESPRESSO, ModConsumableComponents.ESPRESSO_DRINK)
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, "espresso")))));

    public static final class_1792 AFFOGATO = register("affogato", new class_1792(new class_1792.class_1793()
            .method_62833(ModFoodComponents.AFFOGATO_FOOD, ModConsumableComponents.COFFEE_DRINK)
            .method_7889(1)
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, "affogato")))));


    public static <T extends class_1792> T register(String name, T item) {
        return class_2378.method_10230(class_7923.field_41178, CoffeeVariants.id(name), item);
    }

    public static void load() {}
}
