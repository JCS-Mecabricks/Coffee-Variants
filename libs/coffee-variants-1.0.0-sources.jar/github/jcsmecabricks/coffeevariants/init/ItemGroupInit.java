package github.jcsmecabricks.coffeevariants.init;

import github.jcsmecabricks.coffeevariants.CoffeeVariants;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import java.util.Optional;

public class ItemGroupInit {
    public static final class_2561 COFFEE_TITLE = class_2561.method_43471("itemGroup." + CoffeeVariants.MOD_ID + ".coffee_group");
    public static final class_1761 COFFEE_GROUP = register("coffee_group", FabricItemGroup.builder()
            .method_47321(COFFEE_TITLE)
            .method_47320(ItemInit.COFFEE_ITEM::method_7854)
            .method_47317((displayContext, entries) -> class_7923.field_41178.method_10235()
                    .stream()
                    .filter(key -> key.method_12836().equals(CoffeeVariants.MOD_ID))
                    .map(class_7923.field_41178::method_17966)
                    .map(Optional::orElseThrow)
                    .forEach(entries::method_45421))
            .method_47324());
    public static <T extends class_1761> T register(String name, T itemGroup) {
        return class_2378.method_10230(class_7923.field_44687, CoffeeVariants.id(name), itemGroup);
    }
    public static void load() {

    }
}
