package github.jcsmecabricks.coffeevariants.init;

import github.jcsmecabricks.coffeevariants.CoffeeVariants;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class BlockInit {

    public static final class_2248 COFFEE_STATION = registerWithItem("coffee_station", new class_2248(class_4970.class_2251.method_9630(class_2246.field_10161)
            .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(CoffeeVariants.MOD_ID, "coffee_station")))));

    public static <T extends class_2248> T register(String name, T block) {
        return class_2378.method_10230(class_7923.field_41175, CoffeeVariants.id(name), block);
    }
    public static <T extends class_2248> T registerWithItem(String name, T block, class_1792.class_1793 settings) {
        T registered = register(name, block);
        ItemInit.register(name, new class_1747(registered, settings));
        return registered;
    }
    public static <T extends class_2248> T registerWithItem(String name, T block) {
        return registerWithItem(name, block, new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(CoffeeVariants.MOD_ID, name))));
    }
    public static void load() {}
}
