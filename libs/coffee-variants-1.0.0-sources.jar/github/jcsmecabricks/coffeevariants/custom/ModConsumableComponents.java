package github.jcsmecabricks.coffeevariants.custom;

import github.jcsmecabricks.coffeevariants.effect.ModEffects;
import net.minecraft.class_10124;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_3417;

import static net.minecraft.class_10128.method_62859;

public class ModConsumableComponents {
    public static final class_10124 COFFEE_DRINK = method_62859()
            .method_62852(2.0F).method_62855(class_3417.field_20613)
            .method_62851();

    public static final class_10124 ESPRESSO_DRINK = method_62859()
            .method_62852(2.0F)
            .method_62855(class_3417.field_20613)
            .method_62854(new class_10132(new class_1293(ModEffects.CAFFEINE, 1800)))
            .method_62851();
}
