package github.jcsmecabricks.coffeevariants.custom;

import github.jcsmecabricks.coffeevariants.init.ItemInit;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class CoffeeItem extends class_1792 {

    public CoffeeItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (user instanceof class_1657 player) {
            if (!player.method_31548().method_7394(new class_1799(ItemInit.COFFEE_CUP))) {
                // Drop the coffee cup if inventory is full
                player.method_7328(new class_1799(ItemInit.COFFEE_CUP), false);
            }
        }
        // Reduce the consumed item by 1
        return super.method_7861(stack, world, user);
    }
}
