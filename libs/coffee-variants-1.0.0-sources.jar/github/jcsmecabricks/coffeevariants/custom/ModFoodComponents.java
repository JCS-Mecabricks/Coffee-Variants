package github.jcsmecabricks.coffeevariants.custom;

import github.jcsmecabricks.coffeevariants.effect.ModEffects;
import net.minecraft.class_10124;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_4174;

public class ModFoodComponents {
   public static final class_4174 COFFEE_FOOD = new class_4174.class_4175()
           .method_19238(5)
           .method_19240()
           .method_19237(0.3f)
           .method_19242();

   public static final class_4174 MOCHA = new class_4174.class_4175()
           .method_19238(7)
           .method_19240()
           .method_19237(0.6f)
           .method_19242();

   public static final class_4174 LATTE = new class_4174.class_4175()
           .method_19238(7)
           .method_19240()
           .method_19237(0.7f)
           .method_19242();

   public static final class_4174 CAPPUCCINO = new class_4174.class_4175()
           .method_19238(8)
           .method_19240()
           .method_19237(0.6f)
           .method_19242();

   public static final class_4174 ESPRESSO = new class_4174.class_4175()
           .method_19238(7)
           .method_19240()
           .method_19237(1f)
           .method_19242();

   public static final class_4174 AFFOGATO_FOOD = new class_4174.class_4175()
           .method_19238(13)
           .method_19240()
           .method_19237(1f)
           .method_19242();


   public static final class_10124 CAFFEINE_EFFECT = class_10128.method_62858()
           .method_62854(new class_10132(new class_1293(ModEffects.CAFFEINE, 1800), 1f)).method_62851();
}
