package github.jcsmecabricks.coffeevariants;

import github.jcsmecabricks.coffeevariants.effect.ModEffects;
import github.jcsmecabricks.coffeevariants.init.BlockInit;
import github.jcsmecabricks.coffeevariants.init.ItemGroupInit;
import github.jcsmecabricks.coffeevariants.init.ItemInit;
import github.jcsmecabricks.coffeevariants.villager.ModVillagers;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_9306;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CoffeeVariants implements ModInitializer {
	public static final String MOD_ID = "coffee-variants";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Loading...");
		ModEffects.registerEffects();
		ItemGroupInit.load();
		ItemInit.load();
		BlockInit.load();
		ModVillagers.loadVillagers();
		System.out.println("Initializing CoffeeVariantsMod...");
		System.out.println("Items registered successfully!");
		registerCustomTrades();

		ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
			entries.addAfter(class_1802.field_8732, BlockInit.COFFEE_STATION);
		});

		ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(entries -> {
			entries.addAfter(class_1802.field_8680, ItemInit.COFFEE_CUP);
			entries.addAfter(ItemInit.COFFEE_CUP, ItemInit.COFFEE_ITEM);
			entries.addAfter(ItemInit.COFFEE_ITEM, ItemInit.LATTE);
			entries.addAfter(ItemInit.LATTE, ItemInit.CAPPUCCINO);
			entries.addAfter(ItemInit.CAPPUCCINO, ItemInit.MOCHA);
			entries.addAfter(ItemInit.MOCHA, ItemInit.ESPRESSO);
			entries.addAfter(ItemInit.ESPRESSO, ItemInit.AFFOGATO);
		});
	}
	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
	private static void registerCustomTrades() {
		TradeOfferHelper.registerVillagerOffers(ModVillagers.BARISTA, 1, factories -> {
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 2),
					new class_1799(ItemInit.COFFEE_ITEM, 1), 15, 3, 0.04f
			));
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8116, 5),
					new class_1799(class_1802.field_8687, 2), 12, 3, 0.04f
			));
		});
				TradeOfferHelper.registerVillagerOffers(ModVillagers.BARISTA, 2, factories -> {
					factories.add((entity, random) -> new class_1914(
							new class_9306(class_1802.field_8687, 4),
							new class_1799(ItemInit.LATTE, 1), 12, 3, 0.04f
					));
					factories.add((entity, random) -> new class_1914(
							new class_9306(class_1802.field_8103, 1),
							new class_1799(class_1802.field_8687, 3), 12, 3, 0.04f
					));
				});
		TradeOfferHelper.registerVillagerOffers(ModVillagers.BARISTA, 3, factories -> {
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 4),
					new class_1799(ItemInit.MOCHA, 1), 12, 4, 0.04f
			));
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8479, 8),
					new class_1799(class_1802.field_8687, 1), 12, 3, 0.04f
			));
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 5),
					new class_1799(ItemInit.CAPPUCCINO, 1), 12, 3, 0.04f
			));
		});
		TradeOfferHelper.registerVillagerOffers(ModVillagers.BARISTA, 4, factories -> {
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 8),
					new class_1799(ItemInit.ESPRESSO, 1), 12, 5, 0.04f
			));
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8423, 6),
					new class_1799(class_1802.field_8687, 1), 12, 3, 0.04f
			));
		});
		TradeOfferHelper.registerVillagerOffers(ModVillagers.BARISTA, 5, factories -> {
			factories.add((entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 8),
					new class_1799(ItemInit.AFFOGATO, 1), 10, 7, 0.04f
			));
		});
	}
}