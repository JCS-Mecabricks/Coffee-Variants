package github.jcsmecabricks.coffeevariants.effect;

import github.jcsmecabricks.coffeevariants.CoffeeVariants;
import net.minecraft.class_1291;
import net.minecraft.class_1322;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ModEffects {
    public static final class_6880<class_1291> CAFFEINE = registerStatusEffect("caffeine",
            new CaffeineEffect(class_4081.field_18273, 14270550)
                    .method_5566(class_5134.field_23719,
                            class_2960.method_60655(CoffeeVariants.MOD_ID, "caffeine"), 4f,
                            class_1322.class_1323.field_6331)
                    .method_5566(class_5134.field_23728,
                            class_2960.method_60655(CoffeeVariants.MOD_ID, "caffeine"), 1f,
                            class_1322.class_1323.field_6331));


    private static class_6880<class_1291> registerStatusEffect(String name, class_1291 statusEffect) {
        return class_2378.method_47985(class_7923.field_41174, class_2960.method_60655(CoffeeVariants.MOD_ID, name), statusEffect);
    }

    public static void registerEffects() {
        CoffeeVariants.LOGGER.info("Registering Mod Effects for " + CoffeeVariants.MOD_ID);
    }
}
