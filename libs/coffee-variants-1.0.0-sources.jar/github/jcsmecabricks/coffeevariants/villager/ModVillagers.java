package github.jcsmecabricks.coffeevariants.villager;

import com.google.common.collect.ImmutableSet;
import github.jcsmecabricks.coffeevariants.CoffeeVariants;
import github.jcsmecabricks.coffeevariants.init.BlockInit;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3852;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModVillagers {
    public static final class_5321<class_4158> BARISTA_POI_KEY = registerPoiKey("barista_poi");
    public static final class_4158 BARISTA_POI = registerPOI("barista_poi", BlockInit.COFFEE_STATION);

    public static final class_3852 BARISTA = registerProfession("barista", BARISTA_POI_KEY);


    private static class_3852 registerProfession(String name, class_5321<class_4158> type) {
        return class_2378.method_10230(class_7923.field_41195, class_2960.method_60655(CoffeeVariants.MOD_ID, name),
                new class_3852(name, entry -> entry.method_40225(type), entry -> entry.method_40225(type),
                        ImmutableSet.of(), ImmutableSet.of(), class_3417.field_20677));
    }

    private static class_4158 registerPOI(String name, class_2248 block) {
        return PointOfInterestHelper.register(class_2960.method_60655(CoffeeVariants.MOD_ID, name),
                1, 1, block);
    }

    private static class_5321<class_4158> registerPoiKey(String name) {
        return class_5321.method_29179(class_7924.field_41212, class_2960.method_60655(CoffeeVariants.MOD_ID, name));
    }

    public static void  loadVillagers() {
        CoffeeVariants.LOGGER.info("Loading Villagers for" + CoffeeVariants.MOD_ID);
    }
}
