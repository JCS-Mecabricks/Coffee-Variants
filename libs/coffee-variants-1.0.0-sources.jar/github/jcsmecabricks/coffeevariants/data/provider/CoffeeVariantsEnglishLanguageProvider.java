package github.jcsmecabricks.coffeevariants.data.provider;

import github.jcsmecabricks.coffeevariants.CoffeeVariants;
import github.jcsmecabricks.coffeevariants.init.BlockInit;
import github.jcsmecabricks.coffeevariants.init.ItemGroupInit;
import github.jcsmecabricks.coffeevariants.init.ItemInit;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;

public class CoffeeVariantsEnglishLanguageProvider extends FabricLanguageProvider {
    public CoffeeVariantsEnglishLanguageProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }
    private static void addText(@NotNull TranslationBuilder builder, @NotNull class_2561 text, @NotNull String value) {
        if (text.method_10851() instanceof class_2588 translatableTextContent) {
            builder.add(translatableTextContent.method_11022(), value);
        } else {
            CoffeeVariants.LOGGER.warn("Failed to add translation for text: {}", text.getString());
        }
    }

    @Override
    public void generateTranslations(class_7225.class_7874 wrapperLookup, TranslationBuilder translationBuilder) {
        translationBuilder.add(ItemInit.COFFEE_ITEM, "Coffee");
        translationBuilder.add(ItemInit.COFFEE_CUP, "Coffee Cup");
        translationBuilder.add(ItemInit.MOCHA, "Mocha");
        translationBuilder.add(ItemInit.LATTE, "Latte");
        translationBuilder.add(BlockInit.COFFEE_STATION, "Coffee Station");
        translationBuilder.add(ItemInit.CAPPUCCINO, "Cappuccino");
        translationBuilder.add(ItemInit.ESPRESSO, "Espresso");
        translationBuilder.add(ItemInit.AFFOGATO, "Affogato");
        addText(translationBuilder, ItemGroupInit.COFFEE_TITLE, "Coffee Variants");
    }
}
