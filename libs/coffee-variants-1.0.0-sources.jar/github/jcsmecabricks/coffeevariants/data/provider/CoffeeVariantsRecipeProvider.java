package github.jcsmecabricks.coffeevariants.data.provider;

import github.jcsmecabricks.coffeevariants.init.BlockInit;
import github.jcsmecabricks.coffeevariants.init.ItemInit;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_2446;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class CoffeeVariantsRecipeProvider extends FabricRecipeProvider {
    public CoffeeVariantsRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 recipeExporter) {
        return new class_2446(wrapperLookup, recipeExporter) {
            @Override
            public void method_10419() {
                method_62746(class_7800.field_40640, ItemInit.COFFEE_CUP)
                        .method_10434('P', class_1802.field_8407)
                        .method_10439("P P")
                        .method_10439(" P ")
                        .method_10429(method_32807(class_1802.field_8407), method_10426(class_1802.field_8407))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40640, ItemInit.ESPRESSO)
                        .method_10434('S', class_1802.field_8479)
                        .method_10434('P', ItemInit.COFFEE_ITEM)
                        .method_10434('M', class_1802.field_8103)
                        .method_10439(" P ")
                        .method_10439("SMS")
                        .method_10439(" P ")
                        .method_10429(method_32807(class_1802.field_8479), method_10426(class_1802.field_8479))
                        .method_10429(method_32807(class_1802.field_8103), method_10426(class_1802.field_8103))
                        .method_10429(method_32807(ItemInit.COFFEE_ITEM), method_10426(ItemInit.COFFEE_ITEM))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40640, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_8118)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_8118), method_10426(class_1802.field_8118))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_10431(field_53721);

                method_62749(class_7800.field_40640, ItemInit.LATTE)
                        .method_10449(class_1802.field_8103, 2)
                        .method_10454(class_1802.field_8116)
                        .method_10454(ItemInit.COFFEE_ITEM)
                        .method_10442(method_32807(class_1802.field_8116), method_10426(class_1802.field_8116))
                        .method_10442(method_32807(class_1802.field_8103), method_10426(class_1802.field_8103))
                        .method_10442(method_32807(ItemInit.COFFEE_ITEM), method_10426(ItemInit.COFFEE_ITEM))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_8118)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_8118), method_10426(class_1802.field_8118))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "oak_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_8113)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_8113), method_10426(class_1802.field_8113))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "spruce_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_54601)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_54601), method_10426(class_1802.field_54601))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "pale_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_8842)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_8842), method_10426(class_1802.field_8842))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "jungle_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_8651)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_8651), method_10426(class_1802.field_8651))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "acacia_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_40213)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_40213), method_10426(class_1802.field_40213))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "bamboo_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_42687)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_42687), method_10426(class_1802.field_42687))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "cherry_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_8404)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_8404), method_10426(class_1802.field_8404))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "dark_oak_coffee_station")));

                method_62746(class_7800.field_40634, BlockInit.COFFEE_STATION)
                        .method_10434('C', ItemInit.COFFEE_CUP)
                        .method_10434('O', class_1802.field_37507)
                        .method_10439("OOO")
                        .method_10439("OCO")
                        .method_10439("OOO")
                        .method_10429(method_32807(class_1802.field_37507), method_10426(class_1802.field_37507))
                        .method_10429(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_36443(field_53721, String.valueOf(class_2960.method_60655("coffee_variants", "mangrove_coffee_station")));

                method_62749(class_7800.field_40640, ItemInit.CAPPUCCINO)
                        .method_10454(class_1802.field_8103)
                        .method_10454(class_1802.field_8479)
                        .method_10454(class_1802.field_8116)
                        .method_10454(ItemInit.COFFEE_ITEM)
                        .method_10442(method_32807(class_1802.field_8116), method_10426(class_1802.field_8116))
                        .method_10442(method_32807(class_1802.field_8479), method_10426(class_1802.field_8479))
                        .method_10442(method_32807(class_1802.field_8103), method_10426(class_1802.field_8103))
                        .method_10442(method_32807(ItemInit.COFFEE_ITEM), method_10426(ItemInit.COFFEE_ITEM))
                        .method_10431(field_53721);

                method_62749(class_7800.field_40640, ItemInit.MOCHA)
                        .method_10454(class_1802.field_8423)
                        .method_10454(ItemInit.COFFEE_ITEM)
                        .method_10442(method_32807(class_1802.field_8423), method_10426(class_1802.field_8423))
                        .method_10442(method_32807(ItemInit.COFFEE_ITEM), method_10426(ItemInit.COFFEE_ITEM))
                        .method_10431(field_53721);

                method_62749(class_7800.field_40639, ItemInit.COFFEE_ITEM)
                        .method_10454(class_1802.field_8116)
                        .method_10454(ItemInit.COFFEE_CUP)
                        .method_10442(method_32807(class_1802.field_8116), method_10426(class_1802.field_8116))
                        .method_10442(method_32807(ItemInit.COFFEE_CUP), method_10426(ItemInit.COFFEE_CUP))
                        .method_10431(field_53721);


            }
        };
    }


    @Override
    public String method_10321() {
        return "Coffee Variants Recipes";
    }
}
