package github.jcsmecabricks.coffeevariants.data.provider;

import github.jcsmecabricks.coffeevariants.init.BlockInit;
import github.jcsmecabricks.coffeevariants.init.ItemInit;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;

public class CoffeeVariantsModelProvider extends FabricModelProvider {
    public CoffeeVariantsModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {

    }
    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

        itemModelGenerator.method_25733(ItemInit.COFFEE_ITEM, class_4943.field_22938);
        itemModelGenerator.method_25733(ItemInit.COFFEE_CUP, class_4943.field_22938);
        itemModelGenerator.method_25733(ItemInit.MOCHA, class_4943.field_22938);
        itemModelGenerator.method_25733(ItemInit.LATTE, class_4943.field_22938);
        itemModelGenerator.method_25733(ItemInit.CAPPUCCINO, class_4943.field_22938);
        itemModelGenerator.method_25733(ItemInit.ESPRESSO, class_4943.field_22938);
        itemModelGenerator.method_25733(ItemInit.AFFOGATO, class_4943.field_22938);
    }
}
